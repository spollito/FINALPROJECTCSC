package com.example.elevator;

public class VIPPassenger extends Passenger {
    public VIPPassenger(int id, int currentFloor, int destinationFloor) {
        super(id, currentFloor, destinationFloor);
    }
}
