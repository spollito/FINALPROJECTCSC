package com.example.elevator;

public class FreightPassenger extends Passenger {
    public FreightPassenger(int id, int currentFloor, int destinationFloor) {
        super(id, currentFloor, destinationFloor);
    }
}

