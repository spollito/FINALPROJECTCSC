package com.example.elevator;

public class GlassElevator extends Elevator {
    public GlassElevator(int id) {
        super("Glass",id, 6); // Glass elevators have a max capacity of 6 passengers
    }
}

