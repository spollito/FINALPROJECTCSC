package com.example.elevator;

public class ExpressElevator extends Elevator {
    public ExpressElevator(int id) {
        super("Express",id, 8); // Express elevators have a max capacity of 8 passengers
    }
}

