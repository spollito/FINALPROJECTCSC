package com.example.elevator;

public class GlassPassenger extends Passenger {
    public GlassPassenger(int id, int currentFloor, int destinationFloor) {
        super(id, currentFloor, destinationFloor);
    }
}

