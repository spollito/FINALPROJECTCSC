package com.example.elevator;

    public class StandardPassenger extends Passenger {
        public StandardPassenger(int id, int currentFloor, int destinationFloor) {
            super(id, currentFloor, destinationFloor);
        }
    }


